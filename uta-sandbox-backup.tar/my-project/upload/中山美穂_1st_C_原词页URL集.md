# 中山美穂 1st 专辑『「C」』原词页 URL 集

## 专辑信息

| 项目 | 内容 |
|---|---|
| 艺人 | 中山美穂（Miho Nakayama） |
| 专辑 | 『「C」』（第1张录音室专辑，出道专辑） |
| 发售日 | 1985年8月21日（LP / CT）；1985年9月5日（CD，约晚2周） |
| 厂牌 | キングレコード（King Records） |
| 规格品番 | CD：K32X-30（再发盘：GOLD CD 330A-50081 / CD KICS-262 / 2015年Remaster KICS-3261） |
| 总时长 | 38分20秒 |
| Oricon | 最高 11 位 |
| 帯コピー | ただ今、お騒がせ中　未来少女、ひと夏のラブ・ストーリー（通常盤）／中山美穂のスタートは「C」から。瑞々しい感性で新しい恋の関係を歌う。（GOLD CD盤） |
| 曲目 / credits 依据 | 日语维基百科 [「C」 (アルバム)](<https://ja.wikipedia.org/wiki/%E3%80%8CC%E3%80%8D_%28%E3%82%A2%E3%83%AB%E3%83%90%E3%83%A0%29>) |

**阅读说明**

- 「歌词页」指收录**日语原文歌词**的页面（原词页）。全部 URL 均于 2026-09-10～11 逐一进行过 HTTP 状态检查或经搜索引擎索引标题佐证（Uta-Net / Musixmatch / LyricsTranslate 对脚本请求返回 403（Cloudflare 防护），浏览器可直接打开）。
- 各站歌词展示状态：**全文**＝页面直接显示完整歌词；**信息页**＝页面为歌词/曲目检索条目，歌词正文需在 App 内查看。
- 同一首歌在不同站点的标题写法可能略有差异（如 AWA / プチリリ记作「ロンリー・バースディ」、AWA / プチリリ / JOYSOUND 记作「LAST DRIVE」），已在备注中注明。
- 标题曲「C」的 "C" 为 "CLOSE" 的 C（作詞者松本隆于 2022 年电视节目中的说明）；2曲目「スピード・ウェイ」为 1st 单曲「C」的 B 面曲（Album Version）。
- LyricsTranslate 为翻译社区站点，页面同时显示**日语原词**与用户翻译，原词部分供对照参考。

---

## 曲目与原词页

### 01. ときめき（4:00）

- **作詞**: 岩里祐穂 ｜ **作曲**: 岩里未央 ｜ **編曲**: 入江純

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2998369> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/1f323277da199b911390> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210847> | 歌词信息页（正文需 App） |
| LyricsTranslate | <https://lyricstranslate.com/ja/miho-nakayama-tokimeki-lyrics.html> | 原词+翻译对照页，浏览器可访问（脚本访问 403） |

### 02. スピード・ウェイ（Album Version）（3:17）

- **作詞**: 松本隆 ｜ **作曲**: 林哲司 ｜ **編曲**: 萩田光雄
- 备注：1st 单曲「C」B 面曲（1985年6月21日发卖）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/3004425> | 全文，可直接访问（该站表记「スピード・ウェイ(Album Version)」） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2982352> | 全文，可直接访问（同曲另一登录页） |
| J-Lyric | <https://j-lyric.net/artist/a000dc6/l01dbbc.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090849/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/204190/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/cdad431ff3bff69a1f91> | 全文，页面内嵌歌词（表记「スピード・ウェイ(アルバムバージョン)」） |
| JOYSOUND | <https://www.joysound.com/web/search/song/210822> | 歌词信息页（正文需 App） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/88365/> | 全文，浏览器可访问（脚本访问 403） |
| LyricsTranslate | <https://lyricstranslate.com/ja/miho-nakayama-speed-way-lyrics.html> | 原词+翻译对照页，浏览器可访问（脚本访问 403） |

### 03. センチメンタル通信（4:08）

- **作詞**: 宮原芽映 ｜ **作曲**: 萩田光雄 ｜ **編曲**: 鷺巣詩郎

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/3065616> | 全文，可直接访问 |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/31355> | 全文，可直接访问（旧登录页，同曲） |
| AWA | <https://s.awa.fm/track/79a8c0bd52b10fe0a992> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210830> | 歌词信息页（正文需 App） |
| LyricsTranslate | <https://lyricstranslate.com/ja/miho-nakayama-sentimental-tsuushin-lyrics.html> | 原词+翻译对照页，浏览器可访问（脚本访问 403） |

### 04. SEE THROUGH LOVE（3:25）

- **作詞**: 青木久美子 ｜ **作曲**: 林哲司 ｜ **編曲**: 萩田光雄

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/3004852> | 全文，可直接访问（该站表记「See Through Love」） |
| AWA | <https://s.awa.fm/track/12d92eb733f3e80c7093> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210805> | 歌词信息页（正文需 App） |
| LyricsTranslate | <https://lyricstranslate.com/ja/miho-nakayama-see-through-love-lyrics.html> | 原词+翻译对照页，浏览器可访问（脚本访问 403） |

### 05. 「C」（3:25）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 萩田光雄
- 备注：1st 单曲 A 面曲（1985年6月21日发卖）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/876028> | 全文，可直接访问 |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2923015> | 全文，可直接访问（同曲另一登录页） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/255894/> | 全文，可直接访问（歌いだし「トパーズの月明かり」） |
| AWA | <https://s.awa.fm/track/ff4d55d7c87d049ec994> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/5529> | 歌词信息页（正文需 App） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/2187/> | 全文，浏览器可访问（脚本访问 403） |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/c-lyrics/> | 全文（转写可能有误字；页面标注 Written by 松本隆, 筒美京平） |
| LyricsTranslate | <https://lyricstranslate.com/ja/miho-nakayama-c-lyrics.html> | 原词+翻译对照页，浏览器可访问（脚本访问 403） |

### 06. 海を感じる瞬間（とき）（4:08）

- **作詞**: 宮原芽映 ｜ **作曲**: 萩田光雄 ｜ **編曲**: 鷺巣詩郎
- 备注：「瞬間」正式表记读作「とき」（维基标注ルビ）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/3000474> | 全文，可直接访问（表记「海を感じる瞬間」） |
| AWA | <https://s.awa.fm/track/22cbce9a631dd3e69595> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210783> | 歌词信息页（正文需 App） |
| Musixmatch | <https://www.musixmatch.com/lyrics/%E4%B8%AD%E5%B1%B1%E7%BE%8E%E7%A9%82/%E6%B5%B7%E3%82%92%E6%84%9F%E3%81%98%E3%82%8B%E7%9E%AC%E9%96%93> | 歌词页，浏览器可访问（脚本访问 403） |
| LyricsTranslate | <https://lyricstranslate.com/ja/miho-nakayama-umi-wo-kanjiru-toki-lyrics.html> | 原词+翻译对照页，浏览器可访问（脚本访问 403） |

### 07. あいつ（3:49）

- **作詞**: 岩里祐穂 ｜ **作曲**: 馬場孝幸 ｜ **編曲**: 入江純

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/3000475> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/7f1cb6ac0506daf7de96> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210769> | 歌词信息页（正文需 App） |
| LyricsTranslate | <https://lyricstranslate.com/ja/miho-nakayama-aitsu-lyrics.html> | 原词+翻译对照页，浏览器可访问（脚本访问 403） |

### 08. ロンリー・バースデイ（3:56）

- **作詞**: 宮原芽映 ｜ **作曲**: 網倉一也 ｜ **編曲**: 入江純
- 备注：プチリリ / AWA 表记「ロンリー・バースディ」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/3026943> | 全文，可直接访问（该站表记「ロンリー・バースディ」） |
| AWA | <https://s.awa.fm/track/21c17e10433a37be6097> | 全文，页面内嵌歌词（表记「ロンリー・バースディ」） |
| JOYSOUND | <https://www.joysound.com/web/search/song/210904> | 歌词信息页（正文需 App；表记「ロンリー・バースデイ」） |
| LyricsTranslate | <https://lyricstranslate.com/ja/miho-nakayama-lonely-birthday-lyrics.html> | 原词+翻译对照页，浏览器可访问（脚本访问 403） |

### 09. Last Drive（3:57）

- **作詞**: 岩里祐穂 ｜ **作曲**: 岩里未央 ｜ **編曲**: 入江純
- 备注：プチリリ / AWA / JOYSOUND 表记「LAST DRIVE」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/3039206> | 全文，可直接访问（该站表记「LAST DRIVE」） |
| AWA | <https://s.awa.fm/track/b3f6f8a2e73b29099498> | 全文，页面内嵌歌词（表记「LAST DRIVE」） |
| JOYSOUND | <https://www.joysound.com/web/search/song/210896> | 歌词信息页（正文需 App；表记「LAST DRIVE」） |
| LyricsTranslate | <https://lyricstranslate.com/ja/miho-nakayama-last-drive-lyrics.html> | 原词+翻译对照页，浏览器可访问（脚本访问 403） |

### 10. ガラスの雨（4:15）

- **作詞**: 宮原芽映 ｜ **作曲**: 馬場孝幸 ｜ **編曲**: 入江純

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/3039209> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/9d148aa2ef86b56d3499> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210790> | 歌词信息页（正文需 App） |
| Musixmatch | <https://www.musixmatch.com/lyrics/%E4%B8%AD%E5%B1%B1%E7%BE%8E%E7%A9%82/%E3%82%AC%E3%83%A9%E3%82%B9%E3%81%AE%E9%9B%A8> | 歌词页，浏览器可访问（脚本访问 403） |
| LyricsTranslate | <https://lyricstranslate.com/ja/miho-nakayama-glass-no-ame-lyrics.html> | 原词+翻译对照页，浏览器可访问（脚本访问 403） |

---

## 专辑级参考页面

| 页面 | URL |
|---|---|
| 日语维基百科（曲目/credits 依据） | <https://ja.wikipedia.org/wiki/%E3%80%8CC%E3%80%8D_%28%E3%82%A2%E3%83%AB%E3%83%90%E3%83%A0%29> |
| AWA 专辑页（全10曲歌词入口） | <https://s.awa.fm/album/5157c4d4c7832ae94010> |
| プチリリ专辑页（9 曲歌词入口） | <https://petitlyrics.com/lyrics/album/e3808c43e3808d/> |
| SongLyrics 专辑页（「C」歌词入口） | <https://www.songlyrics.com/miho-nakayama/c/> |
| UtaTen 专辑页（单曲关联曲歌词入口） | <https://utaten.com/album/index/403368/> |
| キングレコード商品页（2015 Remaster KICS-3261） | <https://www.kingrecords.co.jp/cs/g/gKICS-3261/> |

## 检索备忘

- 本专辑只有 2 曲为单曲关联曲（「C」A 面 / 「スピード・ウェイ」B 面），这 2 曲在各大歌词站收录较全（スピード・ウェイ 9 源、「C」8 源）；其余 8 首专辑深曲的主体来源为 **プチリリ＋AWA＋JOYSOUND（信息页）＋LyricsTranslate** 4 源组合，其中 J-Lyric / 歌ネット / UtaTen / ORICON 均未收录（已逐一核对各站艺人全曲库）。
- 混同注意：歌ネット 88362 为「ときめきの**季節**」（別曲，1986年），并非本专辑 M-1「ときめき」；JOYSOUND「あいつ」1625 为渡哲也曲、「C」211633 为沢田研二曲，均非本专辑曲（已逐一排除）。
- プチリリ专辑页仅收录 9 曲（缺标题曲「C」本体）、「C」与「スピード・ウェイ」另从艺人曲库补得独立页面；UtaTen 专辑页仅挂出单曲关联的「スピード・ウェイ」1 曲。
- 中山美穂在歌ネット的注册曲共 163 首、UtaTen 139 首、プチリリ 600 首以上，上述深曲均不在其中；SongLyrics 专辑页仅「C」一首有歌词正文（其余 9 曲为无歌词占位行）。
- 歌詞タイム（kasi-time.com）、歌詞GET（kget.jp）等站点已停止解析/无法访问；うたまっぷ（utamap.com）对自动化访问全程超时，未纳入。
- 检索锚点（便于后续补源）：キングレコード artist 页（J-Lyric a000dc6 / 歌ネット 3287 / UtaTen 683 / プチリリ 1922 / ORICON 235308）、AWA 专辑 ID 5157c4d4c7832ae94010。
- 检索与验证日期：2026-09-10～11。
