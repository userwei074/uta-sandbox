# 中森明菜 6th 专辑『POSSIBILITY』原词页 URL 集

## 专辑信息

| 项目 | 内容 |
|---|---|
| 艺人 | 中森明菜（Nakamori Akina） |
| 专辑 | 『POSSIBILITY』（第6张录音室专辑；碟面表记 "7th ALBUM"，为含 best 的官方计数） |
| 发售日 | 1984年10月10日（LP / CT）；1984年10月25日（CD） |
| 厂牌 | リプリーズ・レコード／ワーナー・パイオニア（Warner Pioneer） |
| 规格品番 | LP：L-12592 ／ CT：LKF-8092 ／ CD：35XL-47（主要再发盘：32XL-105(1985)／WPCL-416(1991)／WPC6-8187(1996)／WPCL-10282(2006・纸壳限定)／WPCL-11140(2012・SACD hybrid)／WPJL-10089(2018・重量盘LP)／WPCL-13440～1(2022・ラッカーマスター2CD＋原版伴奏盘、追加 bonuses)） |
| 总时长 | 40分43秒（2022再发盘含 bonuses 49分04秒） |
| Oricon | 最高 1 位（1984年10月22日付・29日付，2周连霸）／1984年度年间 LP 榜 18 位／1985年度年间 39 位 |
| 制作 | プロデューサー：島田雄三 |
| 单曲关联 | 收録第8张单曲「サザン・ウインド」与第9张单曲「十戒 (1984)」；M-4「リ・フ・レ・イ・ン」于专辑发售后（1984年12月15日）以両A面单曲「北ウイング／リ・フ・レ・イ・ン」再发 |
| 曲目 / credits 依据 | 日语维基百科 [POSSIBILITY (中森明菜のアルバム)](<https://ja.wikipedia.org/wiki/POSSIBILITY_%28%E4%B8%AD%E6%A3%AE%E6%98%8E%E8%8F%9C%E3%81%AE%E3%82%A2%E3%83%AB%E3%83%90%E3%83%A0%29>) |

**阅读说明**

- 「歌词页」指收录**日语原文歌词**的页面（原词页）。全部 URL 均于 2026-09-04 逐一进行过 HTTP 状态检查（Uta-Net / Genius / Musixmatch 对脚本请求返回 403（反爬防护），浏览器可直接打开）。
- 各站歌词展示状态：**全文**＝页面直接显示完整歌词；**信息页**＝页面为歌词/曲目检索条目，歌词正文需在 App 内查看。
- 受著作权保护，本文件不转录歌词原文；各曲歌词全文请通过「来源」表中的 URL 访问对应歌词页查看。
- 同一首歌在不同站点的标题写法可能略有差异，已在各曲表格备注中注明。
- SongLyrics 为英文站转载的日语歌词，个别歌词存在转写误差，供对照参考。

---

## 曲目与原词页

### 01. サザン・ウインド（3:52）

- **作詞**: 来生えつこ ｜ **作曲**: 玉置浩二 ｜ **編曲**: 瀬尾一三
- 备注：第8张单曲 A 面曲（1984年4月11日发卖）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l002cfa.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/2062/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/ja00004046/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256425/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/22c9c29b6112d2e69595> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/975> | 歌词信息页（正文需 App） |

---

### 02. 秋はパステルタッチ（4:08）

- **作詞**: 来生えつこ ｜ **作曲**: 高中正義 ｜ **編曲**: 高中正義・瀬尾一三（コーラスアレンジ）

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l047470.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/328171/> | 全文，可直接访问 |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/3240451> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/185445> | 歌词信息页（正文需 App） |

---

### 03. October storm ―十月の嵐―（3:33）

- **作詞**: 康珍化 ｜ **作曲**: 林哲司 ｜ **編曲**: 萩田光雄
- 备注：ORICON / JOYSOUND 表记为「October Storm -十月の嵐-」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l0066b7.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/6791/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060217/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/3599200> | 全文，可直接访问 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256213/> | 全文，可直接访问（歌词数据由 UtaTen 提供）（该站表记「October Storm -十月の嵐-」） |
| AWA | <https://s.awa.fm/track/e4b4223d7fbace26c858> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/6848> | 歌词信息页（正文需 App） |

---

### 04. リ・フ・レ・イ・ン（4:57）

- **作詞**: 松井五郎 ｜ **作曲**: 松田良 ｜ **編曲**: 萩田光雄
- 备注：1984年12月15日以両A面单曲「北ウイング／リ・フ・レ・イ・ン」发卖；TBS系电视剧『恋はミステリー劇場』片尾曲。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l00fbf3.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/42852/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060219/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256212/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/b3f4f4a3e53428099498> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/596> | 歌词信息页（正文需 App） |

---

### 05. 地平線〈ホライゾン〉（4:20）

- **作詞**: 来生えつこ ｜ **作曲**: 来生たかお ｜ **編曲**: 萩田光雄
- 备注：日语维基原文「地平線」上标ルビ「ホライゾン」；ORICON 表记为「地平線」、プチリリ表记为「地平線(ホライゾン)」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l000f4a.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/13661/> | 全文，可直接访问 |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2727531> | 全文，可直接访问（该站表记「地平線(ホライゾン)」） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256214/> | 全文，可直接访问（歌词数据由 UtaTen 提供）（该站表记「地平線」） |
| AWA | <https://s.awa.fm/track/9d1686a3ed89b46d3499> | 全文，页面内嵌歌词 |

---

### 06. 哀愁のMidnight（4:09）

- **作詞**: 有川正沙子 ｜ **作曲**: 玉置浩二 ｜ **編曲**: 萩田光雄

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/328170/> | 全文，可直接访问 |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2727532> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/beb72ebc44f0eedb2700> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/165907> | 歌词信息页（正文需 App） |
| Genius | <https://genius.com/Akina-nakamori-midnight-lyrics> | 全文，浏览器可访问（脚本访问 403） |

---

### 07. 十戒 (1984)（3:35）

- **作詞**: 売野雅勇 ｜ **作曲**: 高中正義 ｜ **編曲**: 高中正義・萩田光雄
- 备注：第9张单曲 A 面曲（1984年7月25日发卖）；JOYSOUND 表记为「十戒(1984)」（无空格）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l0040ac.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/2520/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/ja00004049/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256290/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/52dc9924fb0c0e604c34> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/1187> | 歌词信息页（正文需 App）（该站表记「十戒(1984)」，为中森明菜原曲页；搜索首位 song/1094074 为 Ado 翻唱页，已避开） |

---

### 08. 白い迷い〈ラビリンス〉（4:16）

- **作詞**: 来生えつこ ｜ **作曲**: 来生たかお ｜ **編曲**: 萩田光雄
- 备注：日语维基原文「白い迷い」上标ルビ「ラビリンス」；作曲者来生たかお曾于1984年11月1日以「白いラビリンス（迷い）」名义发售 Self-Cover，检索时勿混淆。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l000f46.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/13658/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/xe15040745/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2748853> | 全文，可直接访问（该站表记「白い迷い (ラビリンス)」） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256215/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/dec89067ba8d32faef02> | 全文，页面内嵌歌词 |

---

### 09. Blue Misty Rain（3:42）

- **作詞**: 有川正沙子 ｜ **作曲**: 松田良 ｜ **編曲**: 萩田光雄

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/328169/> | 全文，可直接访问 |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/3599189> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/1b83783e603af65b5364> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/158182> | 歌词信息页（正文需 App） |
| Genius | <https://genius.com/Akina-nakamori-blue-misty-rain-lyrics> | 全文，浏览器可访问（脚本访问 403） |

---

### 10. ドラマティック・エアポート ―北ウイング Part II―（4:11）

- **作詞**: 康珍化 ｜ **作曲**: 林哲司 ｜ **編曲**: 萩田光雄
- 备注：プチリリ存在「ドラマティック・エアポート～北ウイングPARTⅡ」与「ドラマティック・エアボート -北ウイング Part II-」两种表记的登录。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l0066b8.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/xe15040755/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/3579910> | 全文，可直接访问（该站另有表记「ドラマティック・エアポート～北ウイングPARTⅡ」登录） |
| AWA | <https://s.awa.fm/track/1b941c971313b8ce8073> | 全文，页面内嵌歌词 |

---

## 专辑级参考页面

| 页面 | URL | 验证状态 |
|---|---|---|
| 日语维基百科（曲目/credits 依据） | <https://ja.wikipedia.org/wiki/POSSIBILITY_%28%E4%B8%AD%E6%A3%AE%E6%98%8E%E8%8F%9C%E3%81%AE%E3%82%A2%E3%83%AB%E3%83%90%E3%83%A0%29> | 已抓取核对 |
| プチリリ 专辑歌词一览 | <https://petitlyrics.com/lyrics/album/504f53534942494c495459?artist=%E4%B8%AD%E6%A3%AE+%E6%98%8E%E8%8F%9C> | 已抓取核对 |
| ORICON NEWS 艺人歌词一览（曲名顺） | <https://www.oricon.co.jp/prof/235370/lyrics/title/> | 已抓取核对 |
| J-Lyric 艺人页 | <https://j-lyric.net/artist/a000575/> | 已抓取核对 |
| UtaTen 艺人页 | <https://utaten.com/artist/lyric/685> | 已抓取核对 |
| AWA 艺人页 | <https://s.awa.fm/artist/b5dc9410a476c7171e70> | 已抓取核对 |

## 检索备忘

- 单曲关联曲（サザン・ウインド／十戒 (1984)／リ・フ・レ・イ・ン）全站收录良好；专辑深曲（秋はパステルタッチ／哀愁のMidnight／Blue Misty Rain／ドラマティック・エアポート 等）在 ORICON（4曲未收录）与 JOYSOUND（3曲未收录：地平線／白い迷い／ドラマティック・エアポート）有缺口，但 J-Lyric／歌ネット／UtaTen／プチリリ／AWA 覆盖完整，每曲仍保有 4～7 个来源。
- Uta-Net 对脚本请求全程 403；本文件 Uta-Net URL 均经搜索结果摘要比对「歌いだし」与作詞/作曲信息后收录（如「サザン・ウインド」歌いだし「あいさつするのよ海風に」），浏览器可直接打开。
- 「白い迷い〈ラビリンス〉」检索时须避开作曲者来生たかお本人的 Self-Cover 页（1984年11月发卖）；「十戒 (1984)」须避开 Ado 等他人翻唱页。本文件已逐页核对艺人名。
- SongLyrics 的『POSSIBILITY』专辑页对脚本 403（『NEW AKINA エトランゼ』专辑页可访问），故本文件 SongLyrics 条目仅收录经搜索引擎结果确认的部分。
- AWA 的「秋はパステルタッチ」仅有播放列表页（playlist）条目、未检索到独立 track 页，故该曲未列 AWA 来源。
- 歌詞タイム（kasi-time.com）、歌詞GET（kget.jp）已停止解析／无法访问；うたまっぷ（utamap.com）对自动化访问超时，均未纳入。
- 检索与验证日期：2026-09-04。全部 URL 逐一进行过 HTTP 状态检查（curl，Chrome UA）。
