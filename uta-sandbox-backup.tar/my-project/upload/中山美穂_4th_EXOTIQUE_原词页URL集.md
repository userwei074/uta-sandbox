# 中山美穂 4th 专辑『EXOTIQUE』原词页 URL 集

## 专辑信息

| 项目 | 内容 |
|---|---|
| 艺人 | 中山美穂（Miho Nakayama） |
| 专辑 | 『EXOTIQUE』（第4张录音室专辑） |
| 发售日 | 1986年12月18日（LP / CT / CD 同日） |
| 厂牌 | キングレコード（King Records） |
| 规格品番 | LP：K28A-790 ／ CT：K28H-970 ／ CD：K32X-120（再发盘：GOLD CD 330A-50085 / KICS-266 / 2015年Remaster KICS-3264 / 2022年SACD NKGD-28） |
| 总时长 | 44分08秒 |
| Oricon | 最高 6 位（1987年度年间 45 位） |
| 全曲 credits | 全作詞: 松本隆 ／ 全作曲: 筒美京平 ／ 全編曲: 船山基紀 |
| 曲目 / credits 依据 | 日语维基百科 [EXOTIQUE](https://ja.wikipedia.org/wiki/EXOTIQUE) |

**阅读说明**

- 「歌词页」指收录**日语原文歌词**的页面（原词页）。全部 URL 均于 2026-09-02 逐一进行过 HTTP 状态检查（Genius / Musixmatch 对脚本请求返回 403（Cloudflare 防护），浏览器可直接打开）。
- 各站歌词展示状态：**全文**＝页面直接显示完整歌词；**信息页**＝页面为歌词/曲目检索条目，歌词正文需在 App 内查看。
- 本专辑以异国情调为主题，全曲由「松本隆 × 筒美京平 × 船山基紀」黄金组合创作。

---

## 曲目与原词页

### 01. 炎の舞（4:28）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 船山基紀

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/175938/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090891/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1015791> | 全文，可直接访问（另有投稿版 [2412079](https://petitlyrics.com/lyrics/2412079)） |
| AWA | <https://s.awa.fm/track/17c77c5a547829fb0620/> | 全文，页面内嵌歌词 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/247878/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| Genius | <https://genius.com/Miho-nakayama-hono-no-mai-lyrics> | 全文，浏览器可访问（脚本访问 403） |

### 02. ペニンシュラ・モーニング（4:09）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 船山基紀

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/175937/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090888/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1015784> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/d955a1aedd9e1af29b21/> | 全文，页面内嵌歌词 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/247879/> | 全文，可直接访问 |
| Genius | <https://genius.com/Miho-nakayama-peninshura-moningu-lyrics> | 全文，浏览器可访问（脚本访问 403） |

### 03. 黄金海岸（5:02）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 船山基紀
- 备注：曲名指欧洲人对西非几内亚湾（今加纳一带）地区的旧称「Gold Coast」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/175936/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090821/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2412081> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/2a4b6786a342629b2922/> | 全文，页面内嵌歌词 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/247884/> | 全文，可直接访问 |
| Genius | <https://genius.com/Miho-nakayama-huangjin-haian-lyrics> | 全文，浏览器可访问（脚本访问 403） |

### 04. 霧のケープコッド（4:46）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 船山基紀
- 备注：ケープコッド（Cape Cod）为美国马萨诸塞州东南部半岛。AWA 表记为「霧のケープ・コッド」（带中点）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/175935/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090827/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2412082> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/8bdaa866088139d4dc23/> | 全文，页面内嵌歌词（表记「霧のケープ・コッド」） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/247883/> | 全文，可直接访问 |

### 05. WAKU WAKUさせて（3:56）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 船山基紀
- 备注：先行单曲 A 面曲（1986年11月21日发卖）；中山美穂主演 TBS 系电视剧『な・ま・い・き盛り』主题曲。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000dc6/l005efd.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/4977/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/ja00004096/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/131471> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/744c4288b16636137424/> | 全文，页面内嵌歌词 |
| Musixmatch | <https://www.musixmatch.com/lyrics/%E4%B8%AD%E5%B1%B1/WAKU-WAKU%E3%81%95%E3%81%9B%E3%81%A6> | 歌词页，浏览器可访问（脚本访问 403） |
| Genius | <https://genius.com/Miho-nakayama-waku-waku-waku-waku-sa-sete-lyrics> | 全文，浏览器可访问（脚本访问 403） |

### 06. スウェーデンの城（3:49）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 船山基紀

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/175934/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090847/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1015787> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/2c516f3718525241be25/> | 全文，页面内嵌歌词 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/247881/> | 全文，可直接访问 |
| Genius | <https://genius.com/Miho-nakayama-suu-eden-no-shiro-lyrics> | 全文，浏览器可访问（脚本访问 403） |

### 07. インカの秘宝（4:14）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 船山基紀

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/175933/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090812/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1015799> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/691bb0fd3d2cabb8d626/> | 全文，页面内嵌歌词 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/247885/> | 全文，可直接访问 |
| Genius | <https://genius.com/Miho-nakayama-inka-no-hiho-lyrics> | 全文，浏览器可访问（脚本访问 403） |

### 08. 熱い夜（4:53）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 船山基紀
- 备注：ORICON 页面将编曲记为筒美京平，与本专辑「全編曲: 船山基紀」的记载不一致，以日语维基为准。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/175932/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090803/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2412085> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/9f98abd7093b8f6d0927/> | 全文，页面内嵌歌词 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/247886/> | 全文，可直接访问 |
| Genius | <https://genius.com/Miho-nakayama-atsui-yoru-lyrics> | 全文，浏览器可访问（脚本访问 403） |

### 09. SWITCH ON (ハートのスイッチを押して)（3:52）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 船山基紀
- 备注：单曲「WAKU WAKUさせて」B 面曲「ハートのスイッチを押して」在本专辑中改以「SWITCH ON (ハートのスイッチを押して)」标题收录，**并非版本差异**（同一录音）。因此多数歌词站同时存在两个标题的条目，一并收录。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/11006/> | 全文，可直接访问（表记「SWITCH ON」） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/88359/> | 全文，可直接访问（表记「ハートのスイッチを押して」） |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090846/> | 全文，可直接访问（表记「SWITCH ON」） |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090874/> | 全文，可直接访问（表记「ハートのスイッチを押して」） |
| J-Lyric | <https://j-lyric.net/artist/a000dc6/l00044e.html> | 全文，可直接访问（表记「ハートのスイッチを押して」） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2412086> | 全文，可直接访问（专辑表记） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/29203> | 全文，可直接访问（表记「SWITCH ON」） |
| AWA | <https://s.awa.fm/track/fec0268e6128caaea928/> | 全文，页面内嵌歌词（专辑表记） |
| AWA | <https://s.awa.fm/track/bd23efca909c998f6d35/> | 全文，页面内嵌歌词（单曲名义务页） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/225735/> | 全文，可直接访问（表记「SWITCH ON」） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/204179/> | 全文，可直接访问（表记「ハートのスイッチを押して」） |
| Musixmatch | <https://www.musixmatch.com/lyrics/%E4%B8%AD%E5%B1%B1%E7%BE%8E%E7%A9%82/SWITCH-ON%EF%BC%88%E3%83%8F%E3%83%BC%E3%83%88%E3%81%AE%E3%82%B9%E3%82%A4%E3%83%83%E3%83%81%E3%82%92%E6%8A%BC%E3%81%97%E3%81%A6%EF%BC%89> | 歌词页，浏览器可访问（脚本访问 403） |
| Genius | <https://genius.com/Miho-nakayama-switch-on-switch-on-hato-no-suitchi-o-oshite-lyrics> | 全文，浏览器可访问（脚本访问 403） |

### 10. 時の流れのように（4:52）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 船山基紀

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/175931/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090864/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1015796> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/60d88c7d1ee73bf51229/> | 全文，页面内嵌歌词 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/247880/> | 全文，可直接访问 |
| Genius | <https://genius.com/Miho-nakayama-tokinonagare-no-yo-ni-lyrics> | 全文，浏览器可访问（脚本访问 403） |

---

## 专辑级参考页面

| 页面 | URL |
|---|---|
| 日语维基百科（曲目/credits 依据） | <https://ja.wikipedia.org/wiki/EXOTIQUE> |
| AWA 专辑页（全10曲歌词入口） | <https://s.awa.fm/album/0d41e19668a30d691d13/> |
| Genius 专辑页（Tracklist） | <https://genius.com/albums/Miho-nakayama/Exotique> |
| ORICON NEWS 艺人歌词一览 | <https://www.oricon.co.jp/prof/235308/lyrics/title/> |
| キングレコード EXOTIQUE 页面 | <https://www.kingrecords.co.jp/cs/g/gKICS-3264/> |
| Apple Music（试听） | <https://music.apple.com/jp/album/exotique/606710052> |

## 检索备忘

- 2022年 SACD 『EXOTIQUE+2』附带两张 Bonus Track（WAKU WAKU SASETE Long Version / Instrumental）：Long Version 歌词与第 5 曲「WAKU WAKUさせて」相同（参见上文）；Instrumental 为纯音乐无歌词。
- 本专辑 10 曲在歌ネット（153 曲内）与 UtaTen（139 曲内）均有收录；ORICON 歌词一览（120 曲内）覆盖除「WAKU WAKUさせて」外的全部本专辑曲目。
- Musixmatch 仅对「WAKU WAKUさせて」「SWITCH ON (ハートのスイッチを押して)」两曲有歌词页，其余曲目为「Add lyrics」状态。
- 检索与验证日期：2026-09-02。
