# 中森明菜 4th 专辑『NEW AKINA エトランゼ』原词页 URL 集

## 专辑信息

| 项目 | 内容 |
|---|---|
| 艺人 | 中森明菜（Nakamori Akina） |
| 专辑 | 『NEW AKINA エトランゼ』（第4张录音室专辑） |
| 发售日 | 1983年8月10日（LP / CT）；1983年9月28日（CD）；1983年11月30日（Super Disc SDM-15010） |
| 厂牌 | リプリーズ・レコード／ワーナー・パイオニア（Warner Pioneer） |
| 规格品番 | LP：L-12580 ／ CT：LKF-8080 ／ CD：35XL-15（主要再发盘：32XL-95(1985)／WPCL-413(1991)／WPC6-8185(1996)／WPCL-10279(2006・纸壳限定)／WPCL-11137(2012・SACD hybrid)／WPCL-11725(2014)／WPJL-10086(2018・重量盘LP)／WPCL-13416～7(2022・ラッカーマスター2CD＋原版伴奏盘)） |
| 总时长 | 41分06秒 |
| Oricon | 最高 1 位（1983年8月22日付・29日付，2周连霸）／1983年度年间 LP 榜 10 位；CT 榜最高 1 位 |
| 受赏 | 第25回日本レコード大賞 '83アルバムベスト10 |
| 制作 | ディレクター：島田雄三（与前三作相同）／ヨーロッパ録音 |
| 其他 | 全10曲均为专辑原创曲，无任何已发单曲收录；帯コピー：「ヨーロッパ・レコーディング、撮影、そして新しい作家との出逢い。明菜2年目の歴史がここから始まる。」 |
| 曲目 / credits 依据 | 日语维基百科 [NEW AKINA エトランゼ](<https://ja.wikipedia.org/wiki/NEW_AKINA_%E3%82%A8%E3%83%88%E3%83%A9%E3%83%B3%E3%82%BC>) |

**阅读说明**

- 「歌词页」指收录**日语原文歌词**的页面（原词页）。全部 URL 均于 2026-09-04 逐一进行过 HTTP 状态检查（Uta-Net / Genius / Musixmatch 对脚本请求返回 403（反爬防护），浏览器可直接打开）。
- 各站歌词展示状态：**全文**＝页面直接显示完整歌词；**信息页**＝页面为歌词/曲目检索条目，歌词正文需在 App 内查看。
- 受著作权保护，本文件不转录歌词原文；各曲歌词全文请通过「来源」表中的 URL 访问对应歌词页查看。
- 同一首歌在不同站点的标题写法可能略有差异，已在各曲表格备注中注明。
- SongLyrics 为英文站转载的日语歌词，个别歌词存在转写误差，供对照参考。

---

## 曲目与原词页

### 01. さよならね（4:26）

- **作詞**: 来生えつこ ｜ **作曲**: 来生たかお ｜ **編曲**: 萩田光雄

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l00fbe0.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/55959/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060232/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1184323> | 全文，可直接访问 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256701/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/95fd4e23ea1de138ed09> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/45486> | 歌词信息页（正文需 App） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/sayonara-ne-lyrics/> | 全文（英文站转载・转写可能有误） |
| Genius | <https://genius.com/Akina-nakamori-sayonara-ne-lyrics> | 全文，浏览器可访问（脚本访问 403） |

---

### 02. ヴィーナス誕生（4:49）

- **作詞**: 阿木燿子 ｜ **作曲**: 財津和夫 ｜ **編曲**: 萩田光雄

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l0211f4.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/96815/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060267/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1184370> | 全文，可直接访问 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256700/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/5157ccd0c58a24e94010> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/171555> | 歌词信息页（正文需 App） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/vinasu-tanjo-lyrics/> | 全文（英文站转载・转写可能有误） |
| Musixmatch | <https://www.musixmatch.com/lyrics/Akina-Nakamori/Venus-Tanjo-Karaoke-Version-2022-Mastering> | 歌词页，浏览器可访问（脚本访问 403） |

---

### 03. 少しだけスキャンダル（3:40）

- **作詞**: 翔 ｜ **作曲**: 翔 ｜ **編曲**: 横浜銀蝿、萩田光雄
- 备注：1984年9月～10月日本テレビ系连续剧『瑠璃色ゼネレーション』主题曲（本专辑发售后启用的 tie-up）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l00fbf9.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/38949/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/xe15040746/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2727225> | 全文，可直接访问 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256702/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/31aecc2ec328638caa11> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/7956> | 歌词信息页（正文需 App） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/sukoshi-dake-sukyandaru-lyrics/> | 全文（英文站转载・转写可能有误） |
| Genius | <https://genius.com/artists/Akina-nakamori> | 全文，浏览器可访问（脚本访问 403） |

---

### 04. 感傷紀行（4:11）

- **作詞**: 谷村新司 ｜ **作曲**: 谷村新司 ｜ **編曲**: 萩田光雄

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l000f47.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/13659/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/xe15040728/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1185267> | 全文，可直接访问 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256703/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/cc34a81fff9e45a98c12> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/7817> | 歌词信息页（正文需 App） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/kansho-kiko-lyrics/> | 全文（英文站转载・转写可能有误） |
| Genius | <https://genius.com/Akina-nakamori-kansho-kiko-lyrics> | 全文，浏览器可访问（脚本访问 403） |
| Musixmatch | <https://www.musixmatch.com/lyrics/Akina-Nakamori/the-touch-of-a-heartache-2012-remaster-1> | 歌词页，浏览器可访问（脚本访问 403） |

---

### 05. ルネサンス ―優しさで変えて―（3:27）

- **作詞**: 売野雅勇 ｜ **作曲**: 細野晴臣 ｜ **編曲**: 萩田光雄

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l0211fb.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/96822/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060274/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1194376> | 全文，可直接访问 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256694/> | 全文，可直接访问（歌词数据由 UtaTen 提供）（该站表记「ルネサンス-優しさで変えて-」） |
| AWA | <https://s.awa.fm/track/0d41e9926aaa03691d13> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210765> | 歌词信息页（正文需 App） |

---

### 06. モナムール（グラスに半分の黄昏）（4:11）

- **作詞**: 売野雅勇 ｜ **作曲**: 細野晴臣 ｜ **編曲**: 細野晴臣

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l0211fa.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/96821/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060273/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256695/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/5a86ae915380a6c8f114> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210760> | 歌词信息页（正文需 App） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/monamuuru-gurasuni-hanbunn-no-tasogare-lyrics/> | 全文（英文站转载・转写可能有误） |
| Genius | <https://genius.com/Akina-nakamori-mon-amour-glass-ni-hanbun-no-tasogare-lyrics> | 全文，浏览器可访问（脚本访问 403） |
| Musixmatch | <https://www.musixmatch.com/lyrics/Akina-Nakamori/%E3%83%A2%E3%83%8A%E3%83%A0%E3%83%BC%E3%83%AB-%E3%82%B0%E3%83%A9%E3%82%B9%E3%81%AB%E5%8D%8A%E5%88%86%E3%81%AE%E9%BB%84%E6%98%8F/translation/japanese-romaji> | 歌词页，浏览器可访问（脚本访问 403） |

---

### 07. ストライプ（4:37）

- **作詞**: 来生えつこ ｜ **作曲**: 来生たかお ｜ **編曲**: 萩田光雄

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l0211f9.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/96820/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060272/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256696/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/814cac449a66c9156115> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/117177> | 歌词信息页（正文需 App） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/sutoraippu-lyrics/> | 全文（英文站转载・转写可能有误） |
| Genius | <https://genius.com/Akina-nakamori-stripe-lyrics> | 全文，浏览器可访问（脚本访问 403） |

---

### 08. わくらば色の風（4:47）

- **作詞**: TAKU ｜ **作曲**: TAKU ｜ **編曲**: 横浜銀蝿、萩田光雄
- 备注：日语维基原文「風」上标读音ルビ「ラヴ・ソング」；Uta-Net 表记为「わくらば色の風(ラブソング)」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l0211f8.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/96819/> | 全文，可直接访问（该站表记「わくらば色の風(ラブソング)」） |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060271/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1184365> | 全文，可直接访问 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256697/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/b5be4d7c86b2f480a916> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210767> | 歌词信息页（正文需 App） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/wakuraba-iro-no-kaze-lyrics/> | 全文（英文站转载・转写可能有误） |
| Genius | <https://genius.com/Akina-nakamori-wakurabairo-no-love-song-lyrics> | 全文，浏览器可访问（脚本访问 403） |

---

### 09. 時にはアンニュイ（3:07）

- **作詞**: 阿木燿子 ｜ **作曲**: 財津和夫 ｜ **編曲**: 萩田光雄

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l0211f7.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/96818/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060270/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1190127> | 全文，可直接访问 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256698/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/a25d93602f456e3ed217> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210750> | 歌词信息页（正文需 App） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/toki-ni-wa-annyui-lyrics/> | 全文（英文站转载・转写可能有误） |
| Genius | <https://genius.com> | 全文，浏览器可访问（脚本访问 403） |
| Musixmatch | <https://www.musixmatch.com/lyrics/Akina-Nakamori/%E6%99%82%E3%81%AB%E3%81%AF%E3%82%A2%E3%83%B3%E3%83%8B%E3%83%A5%E3%82%A4> | 歌词页，浏览器可访问（脚本访问 403） |

---

### 10. 覚悟の秋（3:51）

- **作詞**: 谷村新司 ｜ **作曲**: 谷村新司 ｜ **編曲**: 萩田光雄

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000575/l0211f6.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/96817/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060269/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256699/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/2e10d8083d41f2474518> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210740> | 歌词信息页（正文需 App） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/kakugo-no-aki-lyrics/> | 全文（英文站转载・转写可能有误） |
| Genius | <https://genius.com/Akina-nakamori-kakugo-no-aki-lyrics/q/writer> | 全文，浏览器可访问（脚本访问 403） |
| Musixmatch | <https://www.musixmatch.com/lyrics/Akina-Nakamori/%E8%A6%9A%E6%82%9F%E3%81%AE%E7%A7%8B> | 歌词页，浏览器可访问（脚本访问 403） |

---

## 专辑级参考页面

| 页面 | URL | 验证状态 |
|---|---|---|
| 日语维基百科（曲目/credits 依据） | <https://ja.wikipedia.org/wiki/NEW_AKINA_%E3%82%A8%E3%83%88%E3%83%A9%E3%83%B3%E3%82%BC> | 已抓取核对 |
| AWA 专辑页（全10曲歌词入口） | <https://s.awa.fm/album/3028d13e23ba84719060/> | 已验证（页面标题含专辑名） |
| UtaTen 专辑歌词一览 | <https://utaten.com/album/index/133083> | 已抓取核对 |
| プチリリ 专辑歌词一览 | <https://petitlyrics.com/lyrics/album/4e455720414b494e4120e382a8e38388e383a9e383b3e382bc?artist=%E4%B8%AD%E6%A3%AE+%E6%98%8E%E8%8F%9C> | 已抓取核对 |
| SongLyrics 专辑页（英文站） | <https://www.songlyrics.com/akina-nakamori/new-akina/> | 已抓取核对 |
| ORICON NEWS 艺人歌词一览（曲名顺） | <https://www.oricon.co.jp/prof/235370/lyrics/title/> | 已抓取核对 |
| J-Lyric 艺人页 | <https://j-lyric.net/artist/a000575/> | 已抓取核对 |
| AWA 艺人页 | <https://s.awa.fm/artist/b5dc9410a476c7171e70> | 已抓取核对 |
| Warner Music Japan 官方商品页 | <https://wmg.jp/akina/discography/3276/> | 官方页面（JS渲染，脚本抓取无标题） |
| mora 配信页 | <https://mora.jp/package/43000008/A10302B0013838320C/> | 官方配信（JS渲染） |
| CDJournal 再发盘页 | <https://artist.cdjournal.com/d/-/1140004923> | 已抓取核对 |
| Genius 专辑页 | <https://genius.com/albums/Akina-nakamori/New-akina-new-akina-etranger> | 浏览器可访问（脚本 403） |

## 检索备忘

- 本专辑无单曲收录，10曲在各大歌词站的收录呈两个梯队：作家阵容知名曲（さよならね／少しだけスキャンダル／感傷紀行等）几乎全站收录；其余曲目在 J-Lyric／歌ネット／UtaTen／ORICON 亦全部有收录（Warner 时代曲目授权覆盖良好），AWA 与プチリリ补齐剩余长尾。
- Uta-Net 对脚本请求全程返回 403（反爬防护），但本文件全部10条 Uta-Net URL 均经搜索引擎结果摘要逐一比对「歌いだし」（歌词首句）与作詞/作曲信息后收录，浏览器可直接打开。
- JOYSOUND 搜索中「十戒 (1984)」等曲名存在他艺人翻唱页（如 Ado 版 song/1094074），本文件已逐页核对页面标题中的艺人名，仅收录中森明菜本人页面。
- 歌詞タイム（kasi-time.com）、歌詞GET（kget.jp）已停止解析／无法访问；うたまっぷ（utamap.com）对自动化访问超时，均未纳入（与中山美穂专辑任务结论一致）。
- プチリリ站内搜索对脚本 403，专辑歌词一览页仍可直接访问，本文件プチリリ条目均取自专辑页与已验证单曲页。
- 中山美穂任务中发现的检索限制（Genius／Musixmatch 仅浏览器可访问、AWA 页面内嵌歌词）同样适用于本专辑。
- 检索与验证日期：2026-09-04。全部 URL 逐一进行过 HTTP 状态检查（curl，Chrome UA）。
