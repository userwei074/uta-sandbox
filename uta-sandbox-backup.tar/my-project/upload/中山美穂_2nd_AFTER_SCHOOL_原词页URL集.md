# 中山美穂 2nd 专辑『AFTER SCHOOL』原词页 URL 集

## 专辑信息

| 项目 | 内容 |
|---|---|
| 艺人 | 中山美穂（Miho Nakayama） |
| 专辑 | 『AFTER SCHOOL』（第2张录音室专辑） |
| 发售日 | 1985年12月18日（LP / CT）；1986年1月21日（CD） |
| 厂牌 | キングレコード（King Records） |
| 规格品番 | CD：K32X-77（再发盘：GOLD CD 330A-50082 / CD KICS-263 / 2015年Remaster KICS-3262） |
| 总时长 | 37分14秒 |
| Oricon | 最高 13 位 |
| 曲目 / credits 依据 | 日语维基百科 [AFTER SCHOOL (中山美穂のアルバム)](<https://ja.wikipedia.org/wiki/AFTER_SCHOOL_%28%E4%B8%AD%E5%B1%B1%E7%BE%8E%E7%A9%82%E3%81%AE%E3%82%A2%E3%83%AB%E3%83%90%E3%83%A0%29>) |

**阅读说明**

- 「歌词页」指收录**日语原文歌词**的页面（原词页）。全部 URL 均于 2026-09-02 逐一进行过 HTTP 状态检查（Genius / Musixmatch 对脚本请求返回 403（Cloudflare 防护），浏览器可直接打开）。
- 各站歌词展示状态：**全文**＝页面直接显示完整歌词；**信息页**＝页面为歌词/曲目检索条目，歌词正文需在 App 内查看。
- 同一首歌在不同站点的标题写法可能略有差异（如 AWA 记作「HEART BREAK」），已在备注中注明。
- SongLyrics 为英文站转载的日语歌词，个别歌词存在转写误差，供对照参考。

---

## 曲目与原词页

### 01. STARLIGHT VACATION（4:20）

- **作詞**: 森由里子 ｜ **作曲**: 萩田光雄 ｜ **編曲**: 大谷和夫

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2739636> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/beb522bd49f6e7db2700> | 全文，页面内嵌歌词（AWA 表记为「STAR LIGHT VACATION」） |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/starlight-vacation-lyrics/> | 全文（转写可能有误字） |
| JOYSOUND | <https://www.joysound.com/web/search/song/210818> | 歌词信息页（正文需 App） |

### 02. 生意気（3:21）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 船山基紀
- 备注：第2张单曲 A 面曲（1985年10月1日发卖）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000dc6/l00621e.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/5706/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090871/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/876346> | 全文，可直接访问 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/204733/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/a4b99bbc10bc00916a01> | 全文，页面内嵌歌词 |
| Musixmatch | <https://www.musixmatch.com/lyrics/%E4%B8%AD%E5%B1%B1/10295448> | 歌词页，浏览器可访问（脚本访问 403） |
| Genius | <https://genius.com/Miho-nakayama-namaiki-lyrics> | 全文，浏览器可访问（脚本访问 403） |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/shengyi-qi-lyrics/> | 全文（转写可能有误字） |

### 03. けんか友達（4:07）

- **作詞**: 谷穂チロル ｜ **作曲**: 三浦一年 ｜ **編曲**: 大谷和夫

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2739645> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/decb9061ba8937faef02> | 全文，页面内嵌歌词 |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/kenka-tomodachi-lyrics/> | 全文（转写可能有误字） |
| JOYSOUND | <https://www.joysound.com/web/search/song/296286> | 歌词信息页（正文需 App） |

### 04. 放課後（3:23）

- **作詞**: 松本隆 ｜ **作曲**: 筒美京平 ｜ **編曲**: 新川博
- 备注：单曲「BE-BOP-HIGHSCHOOL」B 面曲（专辑先行单曲「BE-BOP-HIGHSCHOOL」本身未收录在本专辑）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000dc6/l01dbba.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/88363/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090889/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2739648> | 全文，可直接访问 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/204174/> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/17eebc59e80549b71703> | 全文，页面内嵌歌词 |
| Genius | <https://genius.com/Miho-nakayama-hokago-lyrics> | 全文，浏览器可访问（脚本访问 403） |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/houkago-lyrics/> | 全文（转写可能有误字） |

### 05. 蒼ざめたペンダント（4:07）

- **作詞**: 三浦徳子 ｜ **作曲**: 馬場孝幸 ｜ **編曲**: 萩田光雄

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2739651> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/2a7979a4f8ee6762f704> | 全文，页面内嵌歌词 |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/aozameta-pendanto-lyrics/> | 全文（转写可能有误字） |
| JOYSOUND | <https://www.joysound.com/web/search/song/210772> | 歌词信息页（正文需 App） |

### 06. あ・そ・び（4:15）

- **作詞**: 岩里祐穂 ｜ **作曲**: 三浦一年 ｜ **編曲**: 大谷和夫

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2739708> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/22999ae5c78703d85405> | 全文，页面内嵌歌词 |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/a-so-bi-lyrics/> | 全文（转写可能有误字） |
| JOYSOUND | <https://www.joysound.com/web/search/song/296284> | 歌词信息页（正文需 App） |

### 07. HEARTBREAK（3:28）

- **作詞**: 岩里祐穂 ｜ **作曲**: 馬場孝幸 ｜ **編曲**: 入江純
- 备注：AWA 表记为「HEART BREAK」（带空格）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2739713> | 全文，可直接访问（该站表记「HEART BREAK」） |
| AWA | <https://s.awa.fm/track/99fc06d28f662e099e06> | 全文，页面内嵌歌词（表记「HEART BREAK」） |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/heartbreak-lyrics/> | 全文（转写可能有误字） |
| JOYSOUND | <https://www.joysound.com/web/search/song/210858> | 歌词信息页（正文需 App） |

### 08. 「U」（3:22）

- **作詞**: 岩里祐穂 ｜ **作曲**: 岩里未央 ｜ **編曲**: 萩田光雄
- 备注：单曲「生意気」B 面曲。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| J-Lyric | <https://j-lyric.net/artist/a000dc6/l01dbbb.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/88364/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/sq15102203/> | 全文，可直接访问（ふりがな付） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2739721> | 全文，可直接访问 |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235308/lyrics/204168/> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/1d0c0c4cc4aef40b5b07> | 全文，页面内嵌歌词 |
| Genius | <https://genius.com/Miho-nakayama-u-lyrics> | 全文，浏览器可访问（脚本访问 403） |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/u-lyrics/> | 全文（转写可能有误字） |

### 09. ストリート・ファンタジー（3:41）

- **作詞**: 三浦徳子 ｜ **作曲**: 馬場孝幸 ｜ **編曲**: 入江純

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2739743> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/702853aaa6249ef01008> | 全文，页面内嵌歌词 |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/sutorito-fantaji-lyrics/> | 全文（转写可能有误字） |
| JOYSOUND | <https://www.joysound.com/web/search/song/210819> | 歌词信息页（正文需 App） |

### 10. 白いはがき（3:09）

- **作詞**: 細田博子 ｜ **作曲**: Frankie T. ｜ **編曲**: 大谷和夫

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2739766> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/95fa4b21e715e738ed09> | 全文，页面内嵌歌词 |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/shiroi-hagaki-lyrics/> | 全文（转写可能有误字） |
| JOYSOUND | <https://www.joysound.com/web/search/song/210813> | 歌词信息页（正文需 App） |

---

## 专辑级参考页面

| 页面 | URL |
|---|---|
| 日语维基百科（曲目/credits 依据） | <https://ja.wikipedia.org/wiki/AFTER_SCHOOL_%28%E4%B8%AD%E5%B1%B1%E7%BE%8E%E7%A9%82%E3%81%AE%E3%82%A2%E3%83%AB%E3%83%90%E3%83%A0%29> |
| AWA 专辑页（全10曲歌词入口） | <https://s.awa.fm/album/0d41e19668a30d691d13/> |
| ORICON NEWS 艺人歌词一览 | <https://www.oricon.co.jp/prof/235308/lyrics/title/> |
| キングレコード商品页（2015 Remaster） | <https://www.kingrecords.co.jp/cs/g/gKICS-3262/> |

## 检索备忘

- 本专辑中单曲关联曲（生意気 / 放課後 / 「U」）在各大歌词站收录较全；其余 7 首专辑深曲在 J-Lyric / 歌ネット / UtaTen / ORICON 均未收录，**プチリリ与 AWA 是目前仅有的两个公开展示全文歌词的站点**，SongLyrics 为英文站转载可作对照。
- 歌詞タイム（kasi-time.com）、歌詞GET（kget.jp）等站点已停止解析/无法访问；うたまっぷ（utamap.com）对自动化访问全程超时，未纳入。
- 中山美穂在歌ネット的注册曲共 153 首、UtaTen 共 139 首，其中均不含上述 7 首深曲，已逐一核对。
- 检索与验证日期：2026-09-02。
