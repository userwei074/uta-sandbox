# 中森明菜 7th 专辑『BITTER AND SWEET』原词页 URL 集

## 专辑信息

| 项目 | 内容 |
|---|---|
| 艺人 | 中森明菜（Akina Nakamori） |
| 专辑 | 『BITTER AND SWEET』（第7张录音室专辑，帯及盘面表记 "8TH ALBUM"） |
| 发售日 | 1985年4月3日（LP / CT）；1985年4月25日（CD） |
| 厂牌 | ワーナー・パイオニア（Warner Pioneer） |
| 规格品番 | LP：L-12593 ｜ CT：LKF-8093 ｜ CD：32XL-61（再发盘：WPCL-417 / WPC6-8188 / 纸壳限定 WPCL-10283 / SACD Hybrid WPCL-11141 / 廉价盘 WPCL-11728 / 180g LP WPJL-10090 / 2023 Lacquer Master Sound WPCL-13449/50） |
| 总时长 | 43分25秒 |
| Oricon | 周榜最高 1 位（连续2周）；1985年年榜 9 位 |
| 制作人 | 島田雄三（アルバム・プロダクション・アドバイザー：角松敏生） |
| 曲目 / credits 依据 | 日语维基百科 [BITTER AND SWEET (中森明菜のアルバム)](<https://ja.wikipedia.org/wiki/BITTER_AND_SWEET_%28%E4%B8%AD%E6%A3%AE%E6%98%8E%E8%8F%9C%E3%81%AE%E3%82%A2%E3%83%AB%E3%83%90%E3%83%A0%29>) |

**阅读说明**

- 「歌词页」指收录**日语原文歌词**的页面（原词页）。全部 URL 均于 2026-09-10～11 逐一进行过 HTTP 状态检查或经搜索引擎索引标题佐证（Uta-Net / Genius / Musixmatch / LyricsTranslate 对脚本请求返回 403（Cloudflare 防护），浏览器可直接打开）。
- 各站歌词展示状态：**全文**＝页面直接显示完整歌词；**信息页**＝页面为歌词/曲目检索条目，歌词正文需在 App 内查看。
- 同一首歌在不同站点的标题写法可能略有差异（如 J-Lyric 记作「BABYLON(バビロン)」、JOYSOUND 记作「UNSTEADY LOVE(アンステディ・ラヴ)」），已在备注中注明。
- 1曲目「飾りじゃないのよ涙は」在本专辑中为**ニュー・リミックス・ヴァージョン**，与 1984 年单曲版为不同混音；プチリリ与 AWA 对两个版本各有独立页面，均已列出。
- 本专辑 2023 年再发盘（WPCL-13449/50）另附 2023 Lacquer Master Sound 音源与原始卡拉 OK 盘；本报告以 1985 年原始盘 10 曲为对象（再发盘附带的单曲版「飾りじゃないのよ涙は」与 B 面曲「ムーンライト・レター」未计入曲目表）。

---

## 曲目与原词页

### 01. 飾りじゃないのよ涙は（ニュー・リミックス・ヴァージョン）（4:31）

- **作詞**: 井上陽水 ｜ **作曲**: 井上陽水 ｜ **編曲**: 萩田光雄
- 备注：第16张单曲 A 面曲（1984年11月14日发卖）的专辑版。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2840183> | 全文，可直接访问（该站表记「飾りじゃないのよ涙は (アルバムバージョン)」＝本专辑版） |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2749898> | 全文，可直接访问（1984年单曲版） |
| J-Lyric | <https://j-lyric.net/artist/a000575/l000b30.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/ja00004037/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/256159/> | 全文，可直接访问（歌词数据由 UtaTen 提供） |
| AWA | <https://s.awa.fm/track/653ab0ae26d41d855f30> | 全文，页面内嵌歌词（表记「BITTER AND SWEET Remix Version [2012 Remaster]」） |
| JOYSOUND | <https://www.joysound.com/web/search/song/2844> | 歌词信息页（正文需 App） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/1266/> | 全文，浏览器可访问（脚本访问 403） |
| Genius | <https://genius.com/Akina-nakamori-kazari-janai-no-yo-namida-wa-lyrics> | 全文，浏览器可访问（脚本访问 403） |

### 02. ロマンティックな夜だわ（3:40）

- **作詞**: EPO ｜ **作曲**: EPO ｜ **編曲**: 清水信之

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2727332> | 全文，可直接访问 |
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1184841> | 全文，可直接访问（旧登录页，同曲） |
| J-Lyric | <https://j-lyric.net/artist/a000575/l00fbe2.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060234/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/255988/> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/bd75bb6b8ca492823e31> | 全文，页面内嵌歌词（2012 Remaster） |
| JOYSOUND | <https://www.joysound.com/web/search/song/8555> | 歌词信息页（正文需 App） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/55961/> | 全文，浏览器可访问（脚本访问 403） |
| Genius | <https://genius.com/Akina-nakamori-romantic-na-yorudawa-lyrics> | 全文，浏览器可访问（脚本访问 403） |

### 03. 予感（4:03）

- **作詞**: 飛鳥涼 ｜ **作曲**: 飛鳥涼 ｜ **編曲**: 椎名和夫
- 备注：飛鳥涼（现 ASKA）提供曲；1985年12月迷你专辑『MY BEST THANKS』中再録（Remastering Remix）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2749911> | 全文，可直接访问 |
| J-Lyric | <https://j-lyric.net/artist/a000575/l000f40.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/ja00004068/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/255991/> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/b7a1b10a1fb799868432> | 全文，页面内嵌歌词（2012 Remaster） |
| JOYSOUND | <https://www.joysound.com/web/search/song/8556> | 歌词信息页（正文需 App） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/13652/> | 全文，浏览器可访问（脚本访问 403；歌いだし「どうせ嫌われるなら」与作詞飛鳥涼/作曲飛鳥涼已经索引摘要核对） |
| Genius | <https://genius.com/Akina-nakamori-yokan-lyrics> | 全文，浏览器可访问（脚本访问 403） |
| LyricsTranslate | <https://lyricstranslate.com/ja/akina-nakamori-%E4%BA%88%E6%84%9F-yokan-lyrics.html> | 原词+翻译对照页，浏览器可访问（脚本访问 403） |

### 04. 月夜のヴィーナス（3:35）

- **作詞**: 松井五郎 ｜ **作曲**: 松岡直也 ｜ **編曲**: 松岡直也

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1185355> | 全文，可直接访问 |
| J-Lyric | <https://j-lyric.net/artist/a000575/l00fbe3.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060235/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/255987/> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/cccb4e1a55d79b660c33> | 全文，页面内嵌歌词（2012 Remaster） |
| JOYSOUND | <https://www.joysound.com/web/search/song/66694> | 歌词信息页（正文需 App） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/55962/> | 全文，浏览器可访问（脚本访问 403） |
| Genius | <https://genius.com/Akina-nakamori-tsukiyo-no-venus-lyrics> | 全文，浏览器可访问（脚本访问 403） |

### 05. BABYLON（4:38）

- **作詞**: SANDII ｜ **作曲**: 久保田麻琴 ｜ **編曲**: 井上鑑
- 备注：12英寸单曲「赤い鳥逃げた」（1985年5月1日发卖）B 面收录了另一版本；歌い出し为说唱段落。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2727333> | 全文，可直接访问 |
| J-Lyric | <https://j-lyric.net/artist/a000575/l047430.html> | 全文，可直接访问（该站表记「BABYLON(バビロン)」） |
| UtaTen（うたてん） | <https://utaten.com/lyric/tu19053108/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/255983/> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/52dd9522fe0a03604c34> | 全文，页面内嵌歌词（2012 Remaster） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/349860/> | 全文，浏览器可访问（脚本访问 403；作詞SANDII/作曲久保田真琴与歌いだし「North, West, South…」已经索引摘要核对） |
| Genius | <https://genius.com/Akina-nakamori-babylon-lyrics> | 全文，浏览器可访问（脚本访问 403） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/babylon-lyrics/> | 全文（转写可能有误字；页面标注 Written by サンディー, 久保田麻琴） |

### 06. UNSTEADY LOVE（4:31）

- **作詞**: 角松敏生 ｜ **作曲**: 角松敏生 ｜ **編曲**: 角松敏生

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2408927> | 全文，可直接访问 |
| J-Lyric | <https://j-lyric.net/artist/a000575/l00fbe4.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060236/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/255986/> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/bd20efcd989c9c8f6d35> | 全文，页面内嵌歌词（2012 Remaster） |
| JOYSOUND | <https://www.joysound.com/web/search/song/8557> | 歌词信息页（正文需 App；该站表记「UNSTEADY LOVE(アンステディ・ラヴ)」） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/55963/> | 全文，浏览器可访问（脚本访问 403） |
| Genius | <https://genius.com/Akina-nakamori-unsteady-love-lyrics> | 全文，浏览器可访问（脚本访问 403） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/unsteady-love-lyrics/> | 全文（转写可能有误字；页面标注 Written by 角松敏生） |

### 07. DREAMING（4:32）

- **作詞**: 斉藤ノブ ｜ **作曲**: 与詞古 ｜ **編曲**: AKAGUY

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2727334> | 全文，可直接访问 |
| J-Lyric | <https://j-lyric.net/artist/a000575/l04743c.html> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/c41a7236a425fe747736> | 全文，页面内嵌歌词（2012 Remaster） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/349859/> | 全文，浏览器可访问（脚本访问 403；作詞斉藤ノブ/作曲与詞古与歌いだし「ちょっとすまし顔で」已经索引摘要核对） |
| Genius | <https://genius.com/Akina-nakamori-dreaming-lyrics> | 全文，浏览器可访问（脚本访问 403） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/dreaming-lyrics/> | 全文（转写可能有误字；页面标注 Written by 与詞古, 斉藤ノブ） |
| LyricsTranslate | <https://lyricstranslate.com/ja/akina-nakamori-dreaming-lyrics.html> | 原词+翻译对照页，浏览器可访问（脚本访问 403） |

### 08. 恋人のいる時間（3:54）

- **作詞**: SHOW ｜ **作曲**: 神保彰 ｜ **編曲**: 井上鑑
- 备注：1986年1月15日『夜のヒットスタジオDELUXE』（富士电视台系）电视披露曲。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2727335> | 全文，可直接访问 |
| J-Lyric | <https://j-lyric.net/artist/a000575/l008017.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060218/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/255989/> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/db83727f5304e09a0937> | 全文，页面内嵌歌词（2012 Remaster） |
| JOYSOUND | <https://www.joysound.com/web/search/song/8558> | 歌词信息页（正文需 App） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/30871/> | 全文，浏览器可访问（脚本访问 403；作詞SHOW/作曲神保彰与歌いだし「ゆっくりシャワーを浴びて」已经索引摘要核对） |
| Genius | <https://genius.com/Akina-nakamori-koibito-no-iru-jikan-lyrics> | 全文，浏览器可访问（脚本访问 403） |

### 09. SO LONG（4:59）

- **作詞**: 角松敏生 ｜ **作曲**: 角松敏生 ｜ **編曲**: 角松敏生、瀬尾一三（ストリングス・アレンジ）

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1183277> | 全文，可直接访问（该站表记「SO LONG (ソーロング)」） |
| J-Lyric | <https://j-lyric.net/artist/a000575/l00fbe5.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060237/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/255985/> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/35677e0855db0f76e238> | 全文，页面内嵌歌词（2012 Remaster） |
| JOYSOUND | <https://www.joysound.com/web/search/song/65409> | 歌词信息页（正文需 App） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/55964/> | 全文，浏览器可访问（脚本访问 403） |
| Genius | <https://genius.com/Akina-nakamori-so-long-lyrics> | 全文，浏览器可访问（脚本访问 403） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/so-long-lyrics/> | 全文（转写可能有误字；页面标注 Written by 角松敏生） |

### 10. APRIL STARS（5:02）

- **作詞**: 吉田美奈子 ｜ **作曲**: 吉田美奈子 ｜ **編曲**: 椎名和夫

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2408882> | 全文，可直接访问 |
| J-Lyric | <https://j-lyric.net/artist/a000575/l00fbe6.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yi15060238/> | 全文，可直接访问（ふりがな付） |
| ORICON NEWS | <https://www.oricon.co.jp/prof/235370/lyrics/255984/> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/905890074467554c2539> | 全文，页面内嵌歌词（2012 Remaster；AWA 表记「APRIL STARS(エイプリル スターズ)」） |
| JOYSOUND | <https://www.joysound.com/web/search/song/54382> | 歌词信息页（正文需 App；该站表记「APRIL STARS(エイプリル・スターズ)」） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/55965/> | 全文，浏览器可访问（脚本访问 403） |
| Genius | <https://genius.com/Akina-nakamori-april-stars-lyrics> | 全文，浏览器可访问（脚本访问 403） |
| SongLyrics | <https://www.songlyrics.com/akina-nakamori/april-stars-lyrics/> | 全文（转写可能有误字；页面标注 Written by 吉田美奈子） |

---

## 专辑级参考页面

| 页面 | URL |
|---|---|
| 日语维基百科（曲目/credits 依据） | <https://ja.wikipedia.org/wiki/BITTER_AND_SWEET_%28%E4%B8%AD%E6%A3%AE%E6%98%8E%E8%8F%9C%E3%81%AE%E3%82%A2%E3%83%AB%E3%83%90%E3%83%A0%29> |
| AWA 专辑页（全10曲歌词入口，2012 Remaster） | <https://s.awa.fm/album/b7a5b10919b394868432> |
| プチリリ专辑页（全10曲歌词入口） | <https://petitlyrics.com/lyrics/album/42495454455220414e44205357454554/> |
| SongLyrics 专辑页（5 曲歌词入口） | <https://www.songlyrics.com/akina-nakamori/bitter-and-sweet/> |
| Warner Music Japan 商品页 | <https://wmg.jp/akina/discography/3280> |

## 检索备忘

- 本专辑 10 曲在 **J-Lyric 全部收录**（10/10），プチリリ与 AWA 也完整覆盖全曲（10/10）；歌ネット 10/10 收录（其中 BABYLON / DREAMING 为 2023 年前后的新登记页 349860 / 349859）。
- UtaTen 收录 9 曲（缺 DREAMING）；ORICON NEWS 收录 9 曲（缺 DREAMING）；JOYSOUND 收录 8 曲（缺 BABYLON / DREAMING——站内「BABYLON」检索 5 件候选（カロンズベカラズ / LA-PPISCH / 今井麻美 / リュ・シウォン / HAN-KUN）均非本曲，「予感」候选中 DIR EN GREY / My Hair is Bad / SUPER BEAVER / 斉藤由貴均非本曲，已逐一排除）。
- 歌ネット_artist ID 3292、ORICON artist ID 235370、プチリリ artist ID 1923、UtaTen artist ID 685、J-Lyric artist ID a000575、AWA 专辑 ID b7a5b10919b394868432（检索锚点，便于后续补源）。
- 「飾りじゃないのよ涙は」专辑版与单曲版在プチリリ为两个独立页面（2840183 / 2749898），引用时注意区分；AWA 收录的为「BITTER AND SWEET Remix Version」（2012 Remaster）。
- 本盘前半 5 曲为曲间无音间隔的连续播放仕様（与同时期安全地帯专辑同类手法）。
- 歌詞タイム（kasi-time.com）、歌詞GET（kget.jp）等站点已停止解析/无法访问；うたまっぷ（utamap.com）对自动化访问全程超时，未纳入。
- 检索与验证日期：2026-09-10～11。
