# 中山美穂 7th 专辑『Mind Game』原词页 URL 集

## 专辑信息

| 项目 | 内容 |
|---|---|
| 艺人 | 中山美穂（Miho Nakayama） |
| 专辑 | 『Mind Game』（第7张录音室专辑） |
| 发售日 | 1988年7月11日（LP / CT / CD）；1989年12月25日（GOLD CD）；1992年11月21日（CD廉価盤）；2015年10月14日（リマスター盤）；2023年8月30日（SACDハイブリッド） |
| 厂牌 | キングレコード（King Records） |
| 规格品番 | LP: K28A 860 ／ CT: K28H 1170 ／ CD: K32X 270 |
| Oricon | 最高 2 位／1988年度年間 36 位 |
| 帯コピー | 夏だからダンサブル!! 心のままに…（通常盤）／心のままに…DANCE WITH ME（GOLD CD） |
| 曲目credits依据 | 日语维基百科 [Mind Game](https://ja.wikipedia.org/wiki/Mind_Game) |

**阅读说明**

- 「歌词页」指收录**日语原文歌词**的页面（原词页）。全部 URL 均于 2026-09-11 逐一进行过 HTTP 状态检查（JOYSOUND 为歌词/曲目信息页，歌词正文需在 App 内查看）。
- 各站歌词展示状态：**全文**＝页面直接显示完整歌词；**信息页**＝页面为歌词/曲目检索条目，歌词正文需在 App 内查看。
- 同一首歌在不同站点的标题写法可能略有差异（如 AWA 多记为全大写），已在备注中注明。
- SongLyrics 为英文站转载的日语歌词，个别歌词存在转写误差，供对照参考。ikuina.com 为歌词聚合站，供对照参考。

---

## 曲目与原词页

### 01. Into The Crowd（1:07）

- **作詞**: 北山瑞穂 ｜ **作曲**: 羽田一郎 ｜ **編曲**: 羽田一郎
- 备注：「北山瑞穂」为中山美穂本人作詞时的別名義。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/6622> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210781/> | 歌词信息页（正文需 App） |

### 02. Strange Parade（3:24）

- **作詞**: 芹沢類 ｜ **作曲**: 羽田一郎 ｜ **編曲**: 杉山卓夫

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/29202> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210820/> | 歌词信息页（正文需 App） |

### 03. Why Not?（3:31）

- **作詞**: 芹沢類 ｜ **作曲**: 羽田一郎 ｜ **編曲**: 杉山卓夫

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/51389> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210887/> | 歌词信息页（正文需 App） |

### 04. Cat Walk（3:54）

- **作詞**: 芹沢類 ｜ **作曲**: KITARO ｜ **編曲**: KITARO

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/15849> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210792/> | 歌词信息页（正文需 App） |

### 05. Moonlight Sexy Dance（4:26）

- **作詞**: 康珍化 ｜ **作曲**: 杉山卓夫 ｜ **編曲**: 杉山卓夫

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/55775> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210892/> | 歌词信息页（正文需 App） |

### 06. In The Morning（5:19）

- **作詞**: 川村真澄 ｜ **作曲**: 久保田利伸 ｜ **編曲**: 杉山卓夫
- 备注：第13张单曲「人魚姫 mermaid」B面曲（专辑版アウトロ与单曲版略有不同）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/6614> | 全文，可直接访问 |
| J-Lyric | <https://j-lyric.net/artist/a000dc6/l010b04.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/43238/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yv15090813/> | 全文，可直接访问（ふりがな付） |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/in-the-morning-lyrics/> | 全文（转写可能有误字） |
| JOYSOUND | <https://www.joysound.com/web/search/song/74780/> | 歌词信息页（正文需 App） |

### 07. Mind Game（4:38）

- **作詞**: 芹沢類 ｜ **作曲**: CINDY・羽田一郎 ｜ **編曲**: 杉山卓夫
- 备注：专辑表题曲。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/52737> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210889/> | 歌词信息页（正文需 App） |

### 08. I Know（5:29）

- **作詞**: 芹沢類 ｜ **作曲**: CINDY ｜ **編曲**: 杉山卓夫

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/1493> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210770/> | 歌词信息页（正文需 App） |

### 09. Velvet Hammer（3:40）

- **作詞**: 川村真澄 ｜ **作曲**: 久保田利伸 ｜ **編曲**: 杉山卓夫

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/77656> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210884/> | 歌词信息页（正文需 App） |

### 10. Take It Easy（4:30）

- **作詞**: 川村真澄 ｜ **作曲**: 久保田利伸 ｜ **編曲**: 杉山卓夫
- 备注：JOYSOUND检索中同名曲均为其他艺人（礼賛/EAGLES/RIP SLYME等），美穗版未收录。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/36098> | 全文，可直接访问 |

### 11. Long Distance To The Heaven（5:20）

- **作詞**: 北山瑞穂 ｜ **作曲**: 北山瑞穂 ｜ **編曲**: 杉山卓夫
- 备注：中山美穂本人作詞・作曲（別名義）。前年冬コンサート「MIHO Catch '88」中以「Long Distance 天国へ」为题演唱，改题后初收録。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/64692> | 全文，可直接访问 |
| SongLyrics | <https://www.songlyrics.com/miho-nakayama/long-distance-to-the-heaven-lyrics/> | 全文（转写可能有误字） |
| JOYSOUND | <https://www.joysound.com/web/search/song/65416/> | 歌词信息页（正文需 App） |

### 12. Husky Town（2:26）

- **作詞**: 芹沢類 ｜ **作曲**: 羽田一郎 ｜ **編曲**: 杉山卓夫

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/42049> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/210862/> | 歌词信息页（正文需 App） |

---

## 专辑级参考页面

| 页面 | URL |
|---|---|
| 日语维基百科（曲目/credits 依据） | <https://ja.wikipedia.org/wiki/Mind_Game> |
| ORICON NEWS 商品页 | <https://www.oricon.co.jp/prof/235308/products/130839/3/> |
| Genius 专辑页（Tracklist+部分曲歌词） | <https://genius.com/albums/Miho-nakayama/Mind-game> |
| プチリリ 专辑页（全12曲歌词入口） | <https://petitlyrics.com/lyrics/album/4d696e642047616d65?artist=%E4%B8%AD%E5%B1%B1%E7%BE%8E%E7%A9%82> |
| J-Lyric 艺人页 | <https://j-lyric.net/artist/a000dc6/> |
| 歌ネット 艺人页 | <https://www.uta-net.com/artist/3287/> |
| UtaTen 艺人页 | <https://utaten.com/artist/lyric/683> |
| プチリリ 艺人页 | <https://petitlyrics.com/lyrics/artist/1922/1-1.html> |
| ORICON NEWS 艺人歌词一览 | <https://www.oricon.co.jp/prof/235308/lyrics/title/> |
| SongLyrics 艺人页 | <https://www.songlyrics.com/miho-nakayama-lyrics/> |

## 检索备忘

- 本专辑为中山美穂音乐性转型之作：起用Cindy并接受久保田利伸制作团队供曲。深曲（非单曲关联曲）在 J-Lyric / 歌ネット / UtaTen / ORICON 均未收录，プチリリ+JOYSOUND 是基础双源。
- JOYSOUND对美穗本专辑收录11/12曲（song id 210770-210892登录段+In The Morning=74780+Long Distance=65416）；仅Take It Easy未收录（站内同名曲均为其他艺人）。
- Oricon歌词一览（136曲核对）不含本专辑曲目；SongLyrics仅收 In The Morning / Long Distance To The Heaven 两曲。
- Genius 有专辑页（Mind Game Lyrics and Tracklist）及美穗艺人页，部分曲目有歌词正文；Genius/Musixmatch 对脚本访问返回403（Cloudflare防护），浏览器可直接打开。
- 全12曲歌词正文目前可直接公开阅读的站点为プチリリ（12曲全部）。
- 检索与验证日期：2026-09-11。
