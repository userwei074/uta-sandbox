# 西村知美 1st 专辑『夢色の瞬間』原词页 URL 集

## 专辑信息

| 项目 | 内容 |
|---|---|
| 艺人 | 西村知美（Tomomi Nishimura） |
| 专辑 | 『夢色の瞬間』（ゆめいろのとき，第1张录音室专辑） |
| 发售日 | 1986年7月16日（LP / CD / CT）；2003年11月27日（纸壳CD再发） |
| 厂牌 | 東芝EMI／EASTWORLD |
| 规格品番 | LP: WTP-90414 ／ CD: CA32-1266 ／ CT: ZH28-1701（再发盘：TOCT-25241） |
| 总时长 | 41分53秒 |
| 曲目credits依据 | 日语维基百科 [夢色の瞬間](https://ja.wikipedia.org/wiki/%E5%A4%A2%E8%89%B2%E3%81%AE%E7%9E%AC%E9%96%93)（LP「夢色の瞬間」歌詞カード出典） |

**阅读说明**

- 「歌词页」指收录**日语原文歌词**的页面（原词页）。全部 URL 均于 2026-09-11 逐一进行过 HTTP 状态检查（JOYSOUND 为歌词/曲目信息页，歌词正文需在 App 内查看）。
- 各站歌词展示状态：**全文**＝页面直接显示完整歌词；**信息页**＝页面为歌词/曲目检索条目，歌词正文需在 App 内查看。
- 同一首歌在不同站点的标题写法可能略有差异（如 AWA 多记为全大写），已在备注中注明。
- SongLyrics 为英文站转载的日语歌词，个别歌词存在转写误差，供对照参考。ikuina.com 为歌词聚合站，供对照参考。

---

## 曲目与原词页

### 01. 夢色のメッセージ

- **作詞**: 来生えつこ ｜ **作曲**: 来生たかお ｜ **編曲**: 萩田光雄
- 备注：デビュー・シングル（1986年3月20日发卖）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/59302> | 全文，可直接访问 |
| J-Lyric | <https://j-lyric.net/artist/a001573/l006630.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yy15110919/> | 全文，可直接访问（ふりがな付） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/6668/> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/24036/> | 歌词信息页（正文需 App） |

### 02. パールの夜

- **作詞**: 来生えつこ ｜ **作曲**: 武部聡志 ｜ **編曲**: 武部聡志

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/78103> | 全文，可直接访问 |

### 03. きららのピアノ

- **作詞**: 吉元由美 ｜ **作曲**: 林哲司 ｜ **編曲**: 新川博

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/17224> | 全文，可直接访问 |

### 04. 風のブティ・ブーケ

- **作詞**: 麻生圭子 ｜ **作曲**: 林哲司 ｜ **編曲**: 鷺巣詩郎
- 备注：プチリリ表记为「風のプティ・ブーケ」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/14876> | 全文，可直接访问（表记「風のプティ・ブーケ」） |
| プチリリ (PetitLyrics) 别登录页 | <https://petitlyrics.com/lyrics/2473604> | 同曲另一登录条目 |

### 05. 星の花束

- **作詞**: 来生えつこ ｜ **作曲**: 来生たかお ｜ **編曲**: 新川博

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/52063> | 全文，可直接访问 |
| J-Lyric | <https://j-lyric.net/artist/a001573/l0084fa.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yy15110916/> | 全文，可直接访问（ふりがな付） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/32123/> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/54352/> | 歌词信息页（正文需 App） |

### 06. 翼にのって

- **作詞**: 来生えつこ ｜ **作曲**: 来生たかお ｜ **編曲**: 鷺巣詩郎
- 备注：单曲「夢色のメッセージ」B面曲。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/35795> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/215332/> | 歌词信息页（正文需 App） |

### 07. FUSHIGI 信じて

- **作詞**: 来生えつこ ｜ **作曲**: 来生たかお ｜ **編曲**: 椎名和夫
- 备注：JOYSOUND表记为「FUSHIGI信じて」（无空格）。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/50121> | 全文，可直接访问 |
| J-Lyric | <https://j-lyric.net/artist/a001573/l0084f8.html> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/yy15110914/> | 全文，可直接访问（ふりがな付） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/32121/> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/54353/> | 歌词信息页（正文需 App） |

### 08. 幸せの白い雲

- **作詞**: 吉元由美 ｜ **作曲**: 林哲司 ｜ **編曲**: 新川博

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/28030> | 全文，可直接访问 |

### 09. 雨上がりのセレナーデ

- **作詞**: 麻生圭子 ｜ **作曲**: 武部聡志 ｜ **編曲**: 武部聡志
- 备注：「セレナーデ」原词表记为「小夜曲」（セレナーデ），プチリリ登录名「雨上りの小夜曲」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/4865> | 全文，可直接访问（表记「雨上りの小夜曲」） |

### 10. イメージの中で～バルセローナ～

- **作詞**: 安井かずみ ｜ **作曲**: 加藤和彦 ｜ **編曲**: 新川博

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/7859> | 全文，可直接访问（表记「イメージの中で ～バルセローナ～」） |

---

## 专辑级参考页面

| 页面 | URL |
|---|---|
| 日语维基百科（曲目/credits 依据） | <https://ja.wikipedia.org/wiki/%E5%A4%A2%E8%89%B2%E3%81%AE%E7%9E%AC%E9%96%93> |
| プチリリ 专辑页（全10曲歌词入口） | <https://petitlyrics.com/lyrics/album/e5a4a2e889b2e381aee79eace99693?artist=%E8%A5%BF%E6%9D%91%20%E7%9F%A5%E7%BE%8E> |
| UtaTen 专辑页（仅挂单曲2曲） | <https://utaten.com/album/index/299594> |
| プチリリ 艺人页 | <https://petitlyrics.com/lyrics/artist/2010/1-1.html> |
| J-Lyric 艺人页 | <https://j-lyric.net/artist/a001573/> |
| 歌ネット 艺人页 | <https://www.uta-net.com/artist/2997/> |
| UtaTen 艺人页 | <https://utaten.com/artist/lyric/13224> |

## 检索备忘

- 本专辑中单曲关联曲（夢色のメッセージ / 星の花束 / FUSHIGI 信じて）在各大歌词站收录较全（4-5源）；其余专辑深曲目前仅プチリリ收录全文歌词，已逐一核对 J-Lyric / 歌ネット / UtaTen / JOYSOUND / AWA 均未收录。
- 歌詞タイム（kasi-time.com）、歌詞GET（kget.jp）等站点已停止解析/无法访问；うたまっぷ（utamap.com）对自动化访问全程超时，未纳入。
- プチリリ对该专辑的登录相当完整（10曲中10曲），标题表记与维基略有差异（風のブティ・ブーケ→風のプティ・ブーケ、雨上がりのセレナーデ→雨上りの小夜曲）。
- 西村知美在歌ネット登录21曲、UtaTen登录40曲、プチリリ登录76曲，其中不含上述深曲，已逐一核对。
- 检索与验证日期：2026-09-11。
