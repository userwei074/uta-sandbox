# 菊池桃子 4th 专辑『ESCAPE FROM DIMENSION』原词页 URL 集

## 专辑信息

| 项目 | 内容 |
|---|---|
| 艺人 | 菊池桃子（Momoko Kikuchi） |
| 专辑 | 『ESCAPE FROM DIMENSION』（第4张录音室专辑） |
| 发售日 | 1987年5月27日 |
| 厂牌 | キャニオン・レコード（Canyon Records） |
| 规格品番 | 维基未记载（LP/CT/CD同时发卖） |
| 全曲统一credits | 作曲：林哲司（全9曲） |
| 曲目credits依据 | 日语维基百科 [菊池桃子]（Discography·アルバム4作目）https://ja.wikipedia.org/wiki/%E8%8F%8A%E6%B1%A0%E6%A1%83%E5%AD%90 |

**阅读说明**

- 「歌词页」指收录**日语原文歌词**的页面（原词页）。全部 URL 均于 2026-09-11 逐一进行过 HTTP 状态检查（JOYSOUND 为歌词/曲目信息页，歌词正文需在 App 内查看）。
- 各站歌词展示状态：**全文**＝页面直接显示完整歌词；**信息页**＝页面为歌词/曲目检索条目，歌词正文需在 App 内查看。
- 同一首歌在不同站点的标题写法可能略有差异（如 AWA 多记为全大写），已在备注中注明。
- SongLyrics 为英文站转载的日语歌词，个别歌词存在转写误差，供对照参考。ikuina.com 为歌词聚合站，供对照参考。

---

## 曲目与原词页

### 01. Starlight Movement

- **作詞**: 青木久美子 ｜ **作曲**: 林哲司 ｜ **編曲**: 林哲司
- 备注：AWA表记「STARLIGHT MOVEMENT」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/29601> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/6914b2fe3d24afb8d626> | 全文，页面内嵌歌词（表记「STARLIGHT MOVEMENT」） |
| JOYSOUND | <https://www.joysound.com/web/search/song/214022/> | 歌词信息页（正文需 App） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/322338/> | 全文，可直接访问 |

### 02. Dreamin' Rider

- **作詞**: 有川正沙子 ｜ **作曲**: 林哲司 ｜ **編曲**: 鷺巣詩郎
- 备注：AWA表记「DREAMIN' RIDER」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/74139> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/9f97a9d409338b6d0927> | 全文，页面内嵌歌词（表记「DREAMIN' RIDER」） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/322336/> | 全文，可直接访问 |

### 03. Yokohama City of Lights

- **作詞**: 売野雅勇 ｜ **作曲**: 林哲司 ｜ **編曲**: 鷺巣詩郎
- 备注：AWA表记「YOKOHAMA CITY OF LIGHTS」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/59892> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/fecf248d6120ceaea928> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/214029/> | 歌词信息页（正文需 App） |

### 04. SAY YES!

- **作詞**: 売野雅勇 ｜ **作曲**: 林哲司 ｜ **編曲**: 林哲司
- 备注：各站表记差异：Say Yes! / SAY YES!。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2925515> | 全文，可直接访问（表记「SAY YES!」） |
| プチリリ (PetitLyrics) 别登录页 | <https://petitlyrics.com/lyrics/31922> | 同曲另一登录条目（表记「Say Yes!」） |
| AWA | <https://s.awa.fm/track/60d78e7e1eef3ff51229> | 全文，页面内嵌歌词（表记「Say Yes!」） |
| J-Lyric | <https://j-lyric.net/artist/a00112e/l004ba0.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/2775/> | 全文，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/1146/> | 歌词信息页（正文需 App） |

### 05. Ivory Coast

- **作詞**: 売野雅勇 ｜ **作曲**: 林哲司 ｜ **編曲**: 久石譲

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2530> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/6536b2aa2edc1d855f30> | 全文，页面内嵌歌词 |
| J-Lyric | <https://j-lyric.net/artist/a00112e/l025418.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/342163/> | 全文，可直接访问 |

### 06. Non Stop the Rain

- **作詞**: 青木久美子 ｜ **作曲**: 林哲司 ｜ **編曲**: 林哲司
- 备注：各站表记：Non Stop The Rain / NON STOP THE RAIN。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/41229> | 全文，可直接访问（表记「Non Stop The Rain」） |
| AWA | <https://s.awa.fm/track/bd79b96f84ac92823e31> | 全文，页面内嵌歌词（表记「NON STOP THE RAIN」） |
| JOYSOUND | <https://www.joysound.com/web/search/song/214026/> | 歌词信息页（正文需 App） |

### 07. Last Runner

- **作詞**: 売野雅勇 ｜ **作曲**: 林哲司 ｜ **編曲**: 林哲司
- 备注：AWA表记「LAST RUNNER」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/61054> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/b7adb30e17bf99868432> | 全文，页面内嵌歌词（表记「LAST RUNNER」） |
| JOYSOUND | <https://www.joysound.com/web/search/song/214030/> | 歌词信息页（正文需 App） |

### 08. 夜明けのバスターミナル

- **作詞**: 有川正沙子 ｜ **作曲**: 林哲司 ｜ **編曲**: 林哲司

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/59893> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/ccc74c1e5ddf9b660c33> | 全文，页面内嵌歌词 |
| JOYSOUND | <https://www.joysound.com/web/search/song/214028/> | 歌词信息页（正文需 App） |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/322335/> | 全文，可直接访问 |

### 09. Sundial

- **作詞**: 売野雅勇 ｜ **作曲**: 林哲司 ｜ **編曲**: 鷺巣詩郎
- 备注：AWA表记「SUNDIAL」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/24678> | 全文，可直接访问 |
| AWA | <https://s.awa.fm/track/52d19726f60203604c34> | 全文，页面内嵌歌词（表记「SUNDIAL」） |
| JOYSOUND | <https://www.joysound.com/web/search/song/214021/> | 歌词信息页（正文需 App） |

---

## 专辑级参考页面

| 页面 | URL |
|---|---|
| 日语维基百科·菊池桃子（Discography，曲目/credits 依据） | <https://ja.wikipedia.org/wiki/%E8%8F%8A%E6%B1%A0%E6%A1%83%E5%AD%90> |
| AWA 专辑页（全9曲歌词入口） | <https://s.awa.fm/album/2fcbd7f21827344bda46/> |
| プチリリ 专辑页（全9曲歌词入口） | <https://petitlyrics.com/lyrics/album/4553434150452046524f4d2044494d454e53494f4e?artist=%E8%8F%8A%E6%B1%A0%20%E6%A1%83%E5%AD%90> |
| J-Lyric 艺人页 | <https://j-lyric.net/artist/a00112e/> |
| 歌ネット 艺人页 | <https://www.uta-net.com/artist/2083/> |
| プチリリ 艺人页 | <https://petitlyrics.com/lyrics/artist/864/1-1.html> |

## 检索备忘

- 本专辑9曲全部实现3源以上：プチリリ+AWA 为双全文源打底，JOYSOUND（214021-214030连续登录段）与歌ネット补足。
- 作曲全部为林哲司（兼部分编曲），编曲由林哲司/鷺巣詩郎/久石譲分担，是菊池桃子专辑中少见的全ATS（林哲司）制作盘。
- 维基的4th专辑曲目表藏于菊池桃子主页面Discography折叠表内，品番未记载，已如实标注。
- AWA的曲名表记多为全大写（STARLIGHT MOVEMENT等），プチリリ表记与维基一致，已在备注注明。
- 检索与验证日期：2026-09-11。
