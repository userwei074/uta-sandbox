# 長山洋子 原创专辑『オンディーヌ』原词页 URL 集

## 专辑信息

| 项目 | 内容 |
|---|---|
| 艺人 | 長山洋子（Yoko Nagayama，偶像歌手活动期） |
| 专辑 | 『オンディーヌ』（Ondine，原创专辑） |
| 发售日 | 1987年8月5日（LP / CT / CD） |
| 厂牌 | ビクター音楽産業（Victor Musical Industries） |
| 专辑构成 | 原创曲6曲+洋乐日本語詞カバー4曲（Robbie Nevil / Fleetwood Mac / Madonna / Cutting Crew） |
| 关联单曲 | 10th单曲「悲しき恋人たち」（1987年6月3日，アルバム・ミックス版收録） |
| 曲目credits依据 | 日语维基百科 [オンディーヌ (長山洋子のアルバム)](https://ja.wikipedia.org/wiki/%E3%82%AA%E3%83%B3%E3%83%87%E3%82%A3%E3%83%BC%E3%83%8C_(%E9%95%B7%E5%B1%B1%E6%B4%8B%E5%AD%90%E3%81%AE%E3%82%A2%E3%83%AB%E3%83%90%E3%83%A0)) |

**阅读说明**

- 「歌词页」指收录**日语原文歌词**的页面（原词页）。全部 URL 均于 2026-09-11 逐一进行过 HTTP 状态检查（JOYSOUND 为歌词/曲目信息页，歌词正文需在 App 内查看）。
- 各站歌词展示状态：**全文**＝页面直接显示完整歌词；**信息页**＝页面为歌词/曲目检索条目，歌词正文需在 App 内查看。
- 同一首歌在不同站点的标题写法可能略有差异（如 AWA 多记为全大写），已在备注中注明。
- SongLyrics 为英文站转载的日语歌词，个别歌词存在转写误差，供对照参考。ikuina.com 为歌词聚合站，供对照参考。

---

## 曲目与原词页

### 01. 真夜中のオンディーヌ

- **作詞**: さかたかずこ ｜ **作曲**: 松岡直也 ｜ **編曲**: 松岡直也

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2779044> | 全文，可直接访问（含作詞/作曲/发售年） |

### 02. ドミノ

- **作詞**: Robbie Nevil, Dick Eastman, Bobby Hart／日本語詞:さかたかずこ ｜ **作曲**: Robbie Nevil, Dick Eastman, Bobby Hart ｜ **編曲**: 松本晃彦
- 备注：Robbie Nevil「Dominoes」（1986）的日本語詞カバー。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2779045> | 全文，可直接访问 |

### 03. 愛を待てないANGELS

- **作詞**: 遠藤京子 ｜ **作曲**: 羽場仁志 ｜ **編曲**: 西平彰

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2779046> | 全文，可直接访问 |

### 04. ビッグ・ラヴ

- **作詞**: Lindsey Buckingham／日本語詞:吉元由美 ｜ **作曲**: Lindsey Buckingham ｜ **編曲**: 西平彰
- 备注：Fleetwood Mac「Big Love」（1987）的日本語詞カバー。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2779047> | 全文，可直接访问 |

### 05. マザーズボーイWOW WOW

- **作詞**: 永井美由紀 ｜ **作曲**: 石田正人 ｜ **編曲**: 松本晃彦
- 备注：作曲者石田正人はバンド「Darlin'」成员。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2779048> | 全文，可直接访问 |

### 06. ラ・イスラ・ボニータ

- **作詞**: Madonna, Pat Leonard, Bruce Gaitsch／日本語詞:南海子 ｜ **作曲**: Madonna, Pat Leonard, Bruce Gaitsch ｜ **編曲**: 西平彰
- 备注：Madonna「La Isla Bonita」（1986）的日本語詞カバー。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2779049> | 全文，可直接访问 |

### 07. ハイウェイ物語（サスペンス）

- **作詞**: 森田由美 ｜ **作曲**: 山崎稔 ｜ **編曲**: 西平彰
- 备注：「物語」标题中注音ルビ为「サスペンス」。プチリリ登录名「ハイウェイ物語」。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2779050> | 全文，可直接访问（表记「ハイウェイ物語」） |

### 08. 愛に抱かれた夜

- **作詞**: Nick Van Eede／日本語詞:森田由美 ｜ **作曲**: Nick Van Eede ｜ **編曲**: 西平彰
- 备注：Cutting Crew「(I Just) Died in Your Arms」（1986）的日本語詞カバー。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2779051> | 全文，可直接访问 |

### 09. 悲しき恋人たち (Twilight-Mix)

- **作詞**: 遠藤京子 ｜ **作曲**: 遠藤京子 ｜ **編曲**: 武部聡志
- 备注：第10张单曲A面曲的アルバム・ミックス（残響抑え/尾音处理不同）。表记差异：Twilight-Mix / ふりがな付页等。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2779970> | 全文，可直接访问 |
| J-Lyric | <https://j-lyric.net/artist/a00046d/l006260.html> | 全文，可直接访问 |
| 歌ネット (Uta-Net) | <https://www.uta-net.com/song/5768/> | 全文，可直接访问 |
| UtaTen（うたてん） | <https://utaten.com/lyric/bk15102230/> | 全文，可直接访问（ふりがな付） |
| AWA | <https://s.awa.fm/track/b6bc487e84bafa80a916> | 全文，页面内嵌歌词 |
| ikuina.com | <https://ikuina.com/lyrics/%E9%95%B7%E5%B1%B1%E6%B4%8B%E5%AD%90/%E6%82%B2%E3%81%97%E3%81%8D%E6%81%8B%E4%BA%BA%E3%81%9F%E3%81%A1-%E9%95%B7%E5%B1%B1%E6%B4%8B%E5%AD%90> | 歌词聚合页，可直接访问 |
| JOYSOUND | <https://www.joysound.com/web/search/song/6135/> | 歌词信息页（正文需 App） |

### 10. アリス

- **作詞**: 遠藤京子 ｜ **作曲**: 遠藤京子 ｜ **編曲**: 西平彰
- 备注：注意与JOYSOUND检索中出现的同名异曲（中国語曲等）区分。

| 来源 | 歌词页 URL | 状态 / 备注 |
|---|---|---|
| プチリリ (PetitLyrics) | <https://petitlyrics.com/lyrics/2779053> | 全文，可直接访问 |

---

## 专辑级参考页面

| 页面 | URL |
|---|---|
| 日语维基百科（曲目/credits 依据） | <https://ja.wikipedia.org/wiki/%E3%82%AA%E3%83%B3%E3%83%87%E3%82%A3%E3%83%BC%E3%83%8C_(%E9%95%B7%E5%B1%B1%E6%B4%8B%E5%AD%90%E3%81%AE%E3%82%A2%E3%83%AB%E3%83%90%E3%83%A0)> |
| プチリリ 专辑页（全10曲歌词入口） | <https://petitlyrics.com/lyrics/album/e382aae383b3e38387e382a3e383bce3838c?artist=%E9%95%B7%E5%B1%B1%20%E6%B4%8B%E5%AD%90> |
| プチリリ 艺人页 | <https://petitlyrics.com/lyrics/artist/1933/1-1.html> |
| J-Lyric 艺人页 | <https://j-lyric.net/artist/a00046d/> |
| 歌ネット 艺人页 | <https://www.uta-net.com/artist/3340/> |
| UtaTen 艺人页 | <https://utaten.com/artist/lyric/709> |
| JOYSOUND 艺人页 | <https://www.joysound.com/web/search/artist/6368/> |

## 检索备忘

- 本专辑为長山洋子偶像活动后期（1987年）的原创专辑，10曲中6曲为原创、4曲为洋乐日本語詞カバー。
- 全10曲在プチリリ以连续ID（2779044-2779053）整专辑登录，是本专辑唯一实现全文公开歌词全覆盖的站点；其余9曲（除悲しき恋人たち）在 J-Lyric（115曲核对）/ 歌ネット（169曲核对）/ UtaTen（244曲核对）/ JOYSOUND / AWA / 歌詞ナビ（40曲核对）/ 歌詞Tube / Lyriha 均未收录，已逐一核对。
- 悲しき恋人たち为单曲关联曲，收录最全（7源）；歌ネット/JOYSOUND/AWA等的長山洋子登录以1988年后演歌期作品为主。
- 歌詞タイム（kasi-time.com）、歌詞GET（kget.jp）已无法访问；うたまっぷ对自动化访问超时；KKBOX/LINE MUSIC/レコチョク等页面无公开展示歌词正文，均未纳入。
- 检索与验证日期：2026-09-11。
